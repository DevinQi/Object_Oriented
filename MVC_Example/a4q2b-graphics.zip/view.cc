//
//  view.cpp
//  a4q2
//
//  Created by Devin Qi on 2015-07-11.
//  Copyright (c) 2015 Devin Qi. All rights reserved.
//

#include "view.h"

View::View(int n):gridSize(n){}
View::~View(){
}
